﻿namespace Wkx
{
    internal class EwkbFlags
    {
        internal const uint HasSrid = 0x20000000;
        internal const uint HasZ = 0x80000000;
        internal const uint HasM = 0x40000000;
    }
}
