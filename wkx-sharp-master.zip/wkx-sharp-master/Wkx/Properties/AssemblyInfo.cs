﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Wkx.Tests")]