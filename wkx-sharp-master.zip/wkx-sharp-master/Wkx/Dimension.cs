﻿namespace Wkx
{
    public enum Dimension
    {
        Xy = 0,
        Xyz = 1,
        Xym = 2,
        Xyzm = 3
    }
}
