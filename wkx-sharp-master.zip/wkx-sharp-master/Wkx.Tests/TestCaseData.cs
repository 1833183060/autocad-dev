﻿namespace Wkx.Tests
{
    public class TestCaseData
    {
        public TestCaseData Results { get; set; }

        public string Wkt { get; set; }
        public string Ewkt { get; set; }
        public string Wkb { get; set; }
        public string Ewkb { get; set; }
        public string WkbXdr { get; set; }
        public string EwkbXdr { get; set; }
        public string EwkbNoSrid { get; set; }
        public string EwkbXdrNoSrid { get; set; }
    }
}
